const CartWidget = () => {
  return (
    <div>CartWidget</div>
  )
}
export default CartWidget