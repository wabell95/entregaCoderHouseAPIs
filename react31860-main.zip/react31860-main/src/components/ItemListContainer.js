const ItemListContainer = ( {greeting} ) => {

  // Ejemplo de entrega

  return (
    <div>ItemListContainer {greeting}</div>
  )
}
export default ItemListContainer