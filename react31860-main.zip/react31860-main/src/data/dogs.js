export const dogs = [
    {id: 1, name:'Firulais', breed:'Husky' },
    {id: 2, name:'Pipo', breed:'Doberman' },
    {id: 3, name:'Moka', breed:'Chihuahua' },
    {id: 4, name:'Milanesa', breed:'Bull Dog' },
    {id: 5, name:'Merlina', breed:'Schnauzer' },
]