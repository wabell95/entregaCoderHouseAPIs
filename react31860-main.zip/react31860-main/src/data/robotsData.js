export const robotsData = [
    {id: 1, name:'Bender', battery: 100 },
    {id: 2, name:'Robocop', battery: 80 },
    {id: 3, name:'Terminator', battery: 70 },
    {id: 4, name:'Wall-E', battery: 50 },
    {id: 5, name:'Juancito', battery: 20 },
]