export const products = [
  {
    id: 1,
    img: "",
    link: "http://lama.dev",
  },
  {
    id: 2,
    img: "",
    link: "http://lama.dev",
  },
  {
    id: 3,
    img: "",
    link: "http://lama.dev",
  },
  {
    id: 4,
    img: "",
    link: "http://lama.dev",
  },
  {
    id: 5,
    img: "",
    link: "http://lama.dev",
  },
  {
    id: 6,
    img: "",
    link: "http://lama.dev",
  },
];
